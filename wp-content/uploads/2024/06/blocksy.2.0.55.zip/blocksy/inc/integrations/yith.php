<?php

add_filter('yith_wcan_content_selector', function ($selector) {
	return '#main-container';
});
